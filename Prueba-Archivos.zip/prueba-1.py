import csv
def menu():
    print("1. Reservar una habitacion")
    print("2. Buscar habitacion")
    print("3. Estado de la habitacion")
    print("4- Ventas Diarias")
    print("5- Guardar informacion")
    print("6- Salir de la habitacion")
def reservar_habitacion():
    nombre = input("Ingrese su nombre: ")
    apellido = input("Ingrese su apellido: ")
    rut = (input("Ingrese su rut: "))
    fecha_ini = input("Ingrese la fecha de hoy con hora: ")
    fecha_fin = input("Ingrese la fecha de termino con hora: ")
def ver_estado(): 
    with open("habitaciones.csv", "r") as archivo:
         lector = csv.reader(archivo)
         next(lector)
         for linea in lector:
              print(linea)
"""def guardar():
    with open("habitaciones.csv", "r") as archivo:
         lector = csv.reader(archivo)
         for linea in lector:
              datos = linea
              with open("archivo.csv", "w") as archivo3:
                escritor = csv.writer(archivo3, delimiter="-")
                escritor.writerow(datos)"""
while True:
    menu()
    opcion = int(input("Seleccione... "))
    if opcion == 1:
        reservar_habitacion()
        continue
    elif opcion == 3:
        ver_estado()
        continue
    #elif opcion == 5:
        guardar()
        continue
    elif opcion == 6:
        break
    
#no supe hacer la funcion guardar, guarda solo el primer valor de mi archivo de habitaciones, este lo hice manual.